package com.example.helloworld

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class SMS_Reciever : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // This method is called when the BroadcastReceiver is receiving an Intent broadcast.
        TODO("SMS_Reciever.onReceive() is not implemented")
    }
}
